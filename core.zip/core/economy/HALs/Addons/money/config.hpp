class cfgHALsMoney {
	debug = 0;
	startingFunds = 0;
	oldManItemsPrice[] = {50, 150, 300, 600};
};
